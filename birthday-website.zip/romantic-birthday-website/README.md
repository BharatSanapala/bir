# Romantic Birthday Website ❤️

## Run locally

npm install
npm run dev

## Build

npm run build

## Docker

docker build -t romantic-birthday .
docker run -p 8080:80 romantic-birthday
