import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Heart, Sparkles, Camera, Stars } from "lucide-react"

export default function RomanticBirthdayWebsite() {
  const [loading, setLoading] = useState(true)
  const [opened, setOpened] = useState(false)
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2500)

    return () => clearTimeout(timer)
  }, [])

  const moveNoButton = () => {
    const isMobile = window.innerWidth < 768

    const x = isMobile
      ? Math.floor(Math.random() * 1200) - 600
      : Math.floor(Math.random() * 700) - 350

    const y = isMobile
      ? Math.floor(Math.random() * 900) - 450
      : Math.floor(Math.random() * 500) - 250

    setNoPosition({ x, y })
  }

  return (
    <div className="min-h-screen bg-black overflow-hidden relative text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,0,140,0.35),transparent_35%)]" />

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(45)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: "110vh" }}
            animate={{
              opacity: [0, 1, 1, 0],
              y: "-10vh",
              x: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 8 + 8,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              fontSize: `${Math.random() * 20 + 10}px`,
            }}
            className="absolute"
          >
            ❤️
          </motion.div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="min-h-screen flex flex-col items-center justify-center text-center px-6 relative z-10"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Heart className="w-28 h-28 fill-pink-500 text-pink-500 mb-8" />
            </motion.div>

            <h1 className="text-5xl sm:text-7xl font-bold mb-6 leading-tight">
              Loading Your Surprise...
            </h1>

            <p className="text-white/70 text-lg sm:text-2xl mb-10 max-w-2xl leading-10">
              Something special made with love is waiting for you 💖
            </p>

            <div className="w-80 h-3 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 2.3 }}
                className="h-full rounded-full bg-gradient-to-r from-pink-500 to-purple-500"
              />
            </div>
          </motion.div>
        ) : !opened ? (
          <motion.div
            key="question"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.8 }}
            className="min-h-screen flex items-center justify-center p-4 relative z-10"
          >
            <div className="relative max-w-2xl w-full rounded-[3rem] border border-white/10 bg-white/10 backdrop-blur-2xl shadow-2xl p-8 sm:p-16 overflow-hidden text-center">
              <div className="absolute -top-24 -right-24 w-72 h-72 bg-pink-500/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl" />

              <motion.div
                animate={{ rotate: [0, 12, -12, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="flex justify-center mb-8"
              >
                <Sparkles className="w-24 h-24 text-pink-400" />
              </motion.div>

              <h1 className="text-5xl sm:text-7xl font-bold leading-tight mb-6">
                Do You Love Me? 😘
              </h1>

              <p className="text-white/70 text-lg sm:text-2xl leading-10 mb-16">
                Warning: there is only one correct answer ❤️
              </p>

              <div className="relative flex items-center justify-center gap-24 sm:gap-40 h-44">
                <motion.button
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setOpened(true)}
                  className="bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 px-10 sm:px-14 py-4 sm:py-5 rounded-3xl text-xl sm:text-2xl font-bold shadow-2xl"
                >
                  Yes ❤️
                </motion.button>

                <motion.button
                  animate={{ x: noPosition.x, y: noPosition.y }}
                  transition={{ type: "spring", stiffness: 300 }}
                  onMouseEnter={moveNoButton}
                  onTouchStart={moveNoButton}
                  onClick={moveNoButton}
                  className="absolute right-0 sm:right-10 bg-white/10 border border-white/10 backdrop-blur-xl px-10 sm:px-14 py-4 sm:py-5 rounded-3xl text-xl sm:text-2xl font-bold"
                >
                  No 😢
                </motion.button>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="website"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="relative z-10"
          >
            <section className="min-h-screen p-4 sm:p-8 flex items-center justify-center">
              <div className="max-w-7xl w-full rounded-[3rem] overflow-hidden border border-white/10 bg-white/10 backdrop-blur-2xl shadow-2xl">
                <div className="grid lg:grid-cols-2">
                  <div className="relative min-h-[450px] lg:min-h-full overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=1200&auto=format&fit=crop"
                      alt="Birthday"
                      className="absolute inset-0 w-full h-full object-cover"
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />

                    <div className="absolute bottom-0 left-0 p-8 sm:p-12">
                      

                      <h1 className="text-4xl sm:text-6xl font-bold leading-tight mb-6">
                        Happy Birthday Mardal
                      </h1>

                      <p className="text-xl sm:text-3xl text-white/80 max-w-xl leading-10">
                        You are my favorite chapter in life.
                      </p>
                    </div>
                  </div>

                  <div className="p-8 sm:p-12 lg:p-16 max-h-[90vh] overflow-y-auto">
                    <motion.h2
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-5xl sm:text-6xl font-bold mb-8 leading-tight"
                    >
                      Dear Love ❤️
                    </motion.h2>

                    <p className="text-white/75 text-lg sm:text-2xl leading-10 mb-8">
                      Every day since the day we met, I feel like my life has been changing in the most beautiful way. You always push me toward becoming a better person, and because of you, I see life differently now.
                    </p>

                    <p className="text-white/75 text-lg sm:text-2xl leading-10 mb-12">
                      I never thought I could love someone this deeply. Even though the time we’ve spent together may be less, within that short time, you created something truly magical in my heart. Before you, I never really dreamed about having anything in life. But now, the only dream I have is us — together, forever.

My days and nights feel incomplete without you, because you are the one who makes them whole. You are not just a chapter in my life… you are my entire story. Without you, there is no “me.”

Sometimes I wonder what my life would have been like if I had never met you… and honestly, I don’t even want to imagine it. You came into my life so quietly, yet changed everything so deeply.

Before you, days used to pass normally. But now, every little thing reminds me of you. Every happy moment makes me want to share it with you first. Every difficult moment feels easier because of you.

You became my comfort without even trying. My safe place. My peace.

And the scariest thing is… I can no longer imagine a life where you are not a part of it. ❤️

All I ever wish for is a lifetime with you by my side. No riches in this world could ever make me feel richer than having you in my life. I treasure you, I adore you, I admire you, and most importantly, I respect you with all my heart.

Once again, I wish you the happiest birthday, my love. ❤️
                    </p>

                    <div className="grid sm:grid-cols-2 gap-5 mb-14">
                      {[
                        "Your smile melts my heart 😊",
                        "Your cute anger 😄",
                        "Your love and care ❤️",
                        "Your voice calms me 🎶",
                      ].map((item, index) => (
                        <motion.div
                          key={index}
                          whileHover={{ y: -8 }}
                          className="rounded-[2rem] bg-white/10 border border-white/10 backdrop-blur-xl p-6"
                        >
                          <Heart className="w-10 h-10 fill-pink-500 text-pink-500 mb-5" />
                          <p className="text-white/80 text-lg sm:text-xl leading-9 font-medium">
                            {item}
                          </p>
                        </motion.div>
                      ))}
                    </div>

                    <div className="mb-14">
                      <div className="flex items-center gap-4 mb-8">
                        <Camera className="text-pink-400 w-10 h-10" />
                        <h3 className="text-4xl font-bold">
                          Our Story 📸
                        </h3>
                      </div>

                      <div className="flex justify-center">
                        <motion.div
                          whileHover={{ scale: 1.02 }}
                          className="rounded-[2rem] overflow-hidden bg-white/10 border border-white/10 backdrop-blur-xl max-w-2xl w-full"
                        >
                          <div className="relative h-[500px] overflow-hidden">
                            <img
                              src="https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=1200&auto=format&fit=crop"
                              alt="Our Memory"
                              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                            />

                            {/* Replace this image URL with your own image */}

                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />

                            <div className="absolute bottom-0 left-0 p-6 sm:p-8">
                              <p className="text-2xl sm:text-3xl text-white font-semibold leading-10">
                                Every memory with you is my favorite memory ❤️
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      </div>
                    </div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      className="rounded-[3rem] bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 p-10 sm:p-14 text-center shadow-2xl"
                    >
                      <Stars className="w-16 h-16 mx-auto mb-6" />

                      <h2 className="text-5xl sm:text-7xl font-bold mb-8 leading-tight">
                        One More Thing...
                      </h2>

                      <p className="text-xl sm:text-3xl leading-[3rem] text-white/90 max-w-3xl mx-auto">
                        No matter what happens in life,
                        I just want you beside me forever. ❤️
                      </p>
                    </motion.div>
                  </div>
                </div>
              </div>
            </section>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
